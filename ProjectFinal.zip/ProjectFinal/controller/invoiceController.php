<?php
require_once('../model/FunctionalitesModel.php');

return getUserAddress();
