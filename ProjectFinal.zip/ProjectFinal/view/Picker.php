<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../asset/css/picker.css">
    <title>Picker</title>
</head>

<body>
    <form method="post" action="../controller/LoginChecker.php"
        style="font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;">
        <table border="1" cellspacing="0" cellpadding="5" width="100%">
            <tr>
                <td colspan=""><img src="../asset/clogo.png" alt="" height="30px"><b>All in One Parcel Service</td>
                <td align="right"> <a href="userLogin.php"> Login!?</a> <a href="index.php"> | Back to Home!?</a></td>
            </tr>

            <tr>
                <td colspan="2">
                    <fieldset>
                        <Legend>Registration Picking Panel</Legend>
                        <table border="1" cellpadding="15" cellspacing="0" align="center" width=40%>
                            <tr>
                                <td align="Center"><a href="userRegistration.html">Member</a></td>
                            </tr>
                            <tr>
                                <td align="Center"><a href="delivermanReg.html">DeliveryMan</a></td>
                            </tr>
                        </table>
                    </fieldset>
                </td>
            </tr>
        </table>
    </form>
</body>

</html>