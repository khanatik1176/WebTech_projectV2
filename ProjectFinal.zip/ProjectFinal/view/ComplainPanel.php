<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../asset/css/MemberComplainPStyle.css">
    <title>Parcel Management</title>
</head>

<body>
    <form action="">
        <table border="1" cellspacing="0" cellpadding="5" align="center" width="600px" height="400px">
            <tr>
                <td colspan="2">Complain TO Admin
                </td>
            </tr>
            <tr>
                <td width="150px">
                    <a href="ComplainAdd.php">Add Complain</a></li>
                </td>
                <td rowspan="4">

                </td>
            </tr>
            <tr>
                <td>
                    <a href="ComplainHistory.php">Update/Edit Complain</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="ComplainHistory.php">Delete Complain</a></li>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="ComplainHistory.php">View Complain History</a></li>
                </td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                <a href="Memberdashboard.php">Back to Home!?</a>
                </td>
            </tr>

        </table>
    </form>
</body>

</html>