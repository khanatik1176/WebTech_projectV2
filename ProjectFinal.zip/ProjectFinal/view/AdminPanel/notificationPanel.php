<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Notification</title>
</head>

<body>
    <form action="">
        <table border="1" cellspacing="0" cellpadding="10" align="center" width="600px" height="400px">
            <tr>
                <td colspan="2" align="center">
                    <a href=""> Notification Panel</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="addNotification.html">Add Notification</a>
                </td>
                <td rowspan="4" width="400px">

                </td>
            </tr>
            <tr>
                <td>
                    <a href="">Update Notification</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href=""> Delete Notification</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="viewNotification.php"> View Notification</a>
                </td>
            </tr>
            <tr>
                <td align="center" colspan="2">
                    <a href="../admindashboard.php" style="text-decoration: none;
                    border: 1px solid black; padding:8px; border-radius:20px;
                    background-color: aqua; color: black;">Back to Home!?</a>
                </td>
            </tr>
        </table>
    </form>
</body>

</html>